package com.capstore.controller;  

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.Order;
import com.capstore.model.Return;
import com.capstore.service.IReturnService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")
public class ReturnGoodsController {


	@Autowired
	private IReturnService returnService;
	
	List<String> files = new ArrayList<String>();
	
	@PostMapping("/addorder")
    public ResponseEntity<Return> addProduct(@RequestBody Return order)
    {
		returnService.addProduct(order);
		if(order==null)
			return new ResponseEntity("Sorry! order is not available", HttpStatus.NOT_FOUND);
		return new ResponseEntity<Return>(order, HttpStatus.OK);
		
    }
	
	
	 
	/*@GetMapping("/myorders")
	public ResponseEntity<List<Order>> getAllOrders() {
		List<Order> orders= orderService.getAllOrders();
	   if (orders==null) {
			new ResponseEntity("No account found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}*/
	
	
	@GetMapping("/myorders/{orderId}")
	public ResponseEntity<Integer> addrecordtoreturn(@PathVariable("orderId") int orderid ) {
		System.out.println(orderid+"printing temp");
		 int myret=returnService.addrecordtoreturn(orderid);
		 return new ResponseEntity<Integer>(myret, HttpStatus.OK);
		 
	}
	/*
	@PostMapping("/deliverOrderAndUpdateInventory")//
	public ResponseEntity<Boolean> deliverOrderAndUpdateInventory(@RequestBody Order order) {
		if (orderService.deliverOrderAndUpdateInventory(order)) {
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
		}
	}
*/
		@GetMapping("/getreturngoods")
		public ResponseEntity<List<Return>> getreturngoods() {
			List<Return> orders= returnService.getreturngoods();
			return new ResponseEntity<List<Return>>(orders, HttpStatus.OK);
		}	
} 
 
