package com.capstore.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capstore.dao.IOrderDao;
import com.capstore.dao.IReturnDao;
import com.capstore.model.Order;
import com.capstore.model.Return;


@Service("returnService")
public class ReturnService implements IReturnService{

	@Autowired
	public IReturnDao returnDao;
	
	@Autowired
	IOrderDao orderDao;
	
	@Override
	public List<Return> getAllReturnDetails() {
		return returnDao.findAll();
	}

	@Override
	public int addrecordtoreturn(int temp) {
		
		Return myreturn = new Return();
		Order myorder=orderDao.findById(temp).get();
		myreturn.setOrder(myorder);
		myreturn.setPickupDate(new Date());
		myreturn.setReturnStatus("success");
		
	 //  myreturn.setCartproduct(myorder.getCart().getCartProducts());
		
	   returnDao.save(myreturn);
	   return myreturn.getReturnId();  
	}
	
	@Override
	public Return checkstatus(int orderid) {
		
		Order myorder=orderDao.findById(orderid).get();
		List<Return> prodreturn = returnDao.findAll();
		for(Return ret:prodreturn)
		{
			if(ret.getOrder().getOrderId()==orderid)
			{
				return ret;
			}
		}
		
		return null;
  	}

	@Override
	public List<Return> getreturngoods() {
		
		return returnDao.findAll();
	}

	@Override
	public Return addProduct(Return order) {
		System.out.println("order1234");
		returnDao.save(order);
		return order;
	}


	

}



