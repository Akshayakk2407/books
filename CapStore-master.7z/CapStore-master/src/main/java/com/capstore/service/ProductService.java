package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IInventoryMerchantDao;
import com.capstore.dao.IProductDao;
import com.capstore.model.Inventory;
import com.capstore.model.Merchant;
import com.capstore.model.Product;

@Service("productService")
public class ProductService {

}