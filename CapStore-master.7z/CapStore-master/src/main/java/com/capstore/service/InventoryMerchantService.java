package com.capstore.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IInventoryMerchantDao;
import com.capstore.dao.IProductDao;
import com.capstore.model.Inventory;


@Service("inventoryMerchantService")
public class InventoryMerchantService {

}
