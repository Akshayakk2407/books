package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.IAddressDao;
import com.capstore.dao.ICustomerDao;
import com.capstore.model.Address;
import com.capstore.model.Customer;

import ch.qos.logback.core.net.SyslogOutputStream;

@Service("addressService")
public class AddressService {


}