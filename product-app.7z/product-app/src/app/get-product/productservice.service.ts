import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import{Iproduct} from './IProduct';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  url:string="assets/products.json";

  productList: Iproduct[];
  constructor(private http:HttpClient) { 
    
  }
/*   getproducts():Observable<Iproduct []>
  {
    return this.http.get<Iproduct []>(this.url);
    
  } */

  getproducts():any{
    this.http.get<Iproduct[]>(this.url).subscribe(res=>{
      console.log(res);
      this.productList=res;
    })
  }
}
