import { Component, OnInit } from '@angular/core';
import { Iproduct } from './IProduct';
import { ProductserviceService } from './productservice.service';
@Component({
  selector: 'app-get-product',
  templateUrl: './get-product.component.html',
  styleUrls: ['./get-product.component.css']
})
export class GetProductComponent implements OnInit {
 // products:Iproduct[];

  constructor(private service:ProductserviceService) {
  }
  ngOnInit() {
      //this.service.getproducts().subscribe(d=>this.products=d);
     if(this.service.productList==undefined)   //this.service.productList
        this.service.getproducts();
    }
}
