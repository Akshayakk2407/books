import { Component, OnInit } from '@angular/core';
import { Iproduct } from '../get-product/IProduct';
import { ProductserviceService } from '../get-product/productservice.service';

@Component({
  selector: 'app-buy-product',
  templateUrl: './buy-product.component.html',
  styleUrls: ['./buy-product.component.css']
})
export class BuyProductComponent implements OnInit {

  products:Iproduct[];
AvailableBalance:number=2000;
   isPrice:boolean=false;
  constructor(private service:ProductserviceService) {
  }
  ngOnInit() {
    if(this.service.productList==undefined)
    this.service.getproducts();
    }
    //Balance
    buy(b){
      if(b.ProductPrice<=this.AvailableBalance){
        this.AvailableBalance=this.AvailableBalance - b.ProductPrice;
        this.isPrice=false;
      }
  else{
    this.isPrice=true;
  }
    }

}
