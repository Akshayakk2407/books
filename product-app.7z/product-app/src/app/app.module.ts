import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { GetProductComponent } from './get-product/get-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { BuyProductComponent } from './buy-product/buy-product.component';
import {Route, RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms';


const routes:Route[]=[
  {
    path:'get',
    component:GetProductComponent
  },
  {
    path:'add',
    component:AddProductComponent
  },
  {
    path:'buy',
    component:BuyProductComponent
  }
  
];
@NgModule({
  declarations: [
    AppComponent,
    GetProductComponent,
    AddProductComponent,
    BuyProductComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
