import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from 'src/app/get-product/productservice.service';
import { isNumber } from 'util';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  id;
  name:string;
  quantity;
  price;

  constructor(private service:ProductserviceService) { }

  ngOnInit() {
    if(this.service.productList==undefined)
    this.service.getproducts();
  }

  add(){
    if(this.id<999){
      alert('sorry atleast 4 digits needed')
    }
    if(this.name==undefined || this.name.length==0){
      alert('name is required')
    }
    else if(this.name.length<2){
      alert('should be greater than 2');
    }
    this.service.productList.push({   
       ProductId:this.id,
      ProductName:this.name,
      ProductQuantity:this.quantity,
      ProductPrice:this.price
    });
      console.log(this.service.productList)
  }
}
