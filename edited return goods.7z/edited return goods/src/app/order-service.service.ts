import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iproduct } from './orders/Iproduct';

@Injectable({
  providedIn: 'root'
})
export class OrderServiceService {

  public products:Iproduct[];

  constructor() {
    this.products = [
        { id: 100, name: 'Tv', price: 10000, quantity : 3},
        { id: 101, name: 'Ac', price: 20000, quantity : 63 },
        { id: 102, name: 'Mobile', price: 30500, quantity : 54 },
        { id: 103, name: 'Laptop', price: 40000, quantity : 6 },
        { id: 104, name: 'Tablet', price: 5000, quantity : 5 },
        { id: 105, name: 'Fridge', price: 6500, quantity : 23 },
        { id: 106, name: 'Shoes', price: 700, quantity : 32 }
    ];
}
   
findAll():Iproduct[] {
  return this.products;
}
}
