import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from '../order-service.service';
import { Iproduct } from './Iproduct';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  products:Iproduct[];

  constructor(private service:OrderServiceService) { }

  ngOnInit() {
    this.products = this.service.findAll();

  }
  order(data:any){
    console.log(data);
     if(this.service.products.find(x=>x.id==data))
     {
       let product = this.service.products.find(x=>x.id==data);

      product.quantity += 1; 
      console.log(product);
     }
  }

}
