export interface Iproduct{
    id:number;
    name:string;
    price:number;
    quantity:number;

}
