import { Component, OnInit } from '@angular/core';
import { OrderServiceService } from '../order-service.service';
import { Iproduct } from '../orders/Iproduct';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  product:Iproduct[];

  constructor(private service:OrderServiceService) { }

  ngOnInit() {

    this.product=this.service.findAll();

    }
}
